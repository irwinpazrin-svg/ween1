<?php

namespace App\Controllers;

use App\Models\MejaModel;

class Meja extends BaseController
{
    protected $mejaModel;

    public function __construct()
    {
        $this->mejaModel = new MejaModel(); // Inisialisasi model
    }

    public function index()
    {
        $data['semua_meja'] = $this->mejaModel->getAllMeja(); // Ambil semua meja
        return view('meja_view', $data); // Ganti 'meja_view' dengan nama view Anda
    }

    // Fungsi untuk mengubah status meja
    public function ubahStatusMeja()
    {
        if (!session()->get('nama') || session()->get('rule') != 1) {
            return redirect()->to(base_url() . "/dashboard");  // Prevent unauthorized access
        }
    
        $nomor_meja = $this->request->getPost('nomor_meja');
        $status = $this->request->getPost('status');
    
        log_message('debug', 'Data dari form - Nomor Meja: ' . $nomor_meja . ', Status: ' . $status);
        
        // Jika status adalah 'terboking', simpan waktu saat ini
        if ($status == 'terboking') {
            $data = [
                'status' => 'terboking',
                'waktu_terboking' => date('Y-m-d H:i:s')  // Set waktu saat ini
            ];
        } else {
            // Jika status bukan 'terboking', reset waktu_terboking ke null
            $data = [
                'status' => $status,
                'waktu_terboking' => null
            ];
        }

        // Update status meja dan waktu terboking di database
        if ($this->mejaModel->update($nomor_meja, $data)) {
            return redirect()->to('/meja')->with('message', 'Status meja berhasil diubah.');
        } else {
            return redirect()->to('/meja')->with('message', 'Gagal mengubah status meja.');
        }
    }

    // Tambahan fungsi lainnya seperti add, edit, delete, dll.
}
