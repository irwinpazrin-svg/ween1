<!DOCTYPE html>
<html lang="en">
<?php $url = current_url(true); ?>

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>RFcafe | <?= $url->getSegment(3) ?> </title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/feather/feather.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/typicons/typicons.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/simple-line-icons/css/simple-line-icons.css">
    <!-- endinject -->
    <!-- Plugin css for this page -->
    <!-- End plugin css for this page -->
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url() ?>/public/css/vertical-layout-light/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?= base_url() ?>/public/images/LogoCafe.JPG" />

    <script src="<?php echo base_url() ?>/public/js/jquery/jquery.min.js"></script>
    <style>
    body {
        background-color: #cfd8dc; /* Warna latar belakang */
        background-image: url('<?= base_url() ?>/public/images/cafe_b.JPEG'); /* Tambahkan gambar */
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
    }

    .content-wrapper {
        background-color: rgba(255, 255, 255, 0.9); /* Warna putih dengan transparansi */
        border-radius: 10px; /* Membuat sudut membulat */
        padding: 20px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Tambahkan efek bayangan */
    }

    .sidebar {
        background-color: #455a64; /* Warna sidebar */
        color: white; /* Warna teks sidebar */
    }

    .sidebar .nav-item.active {
        background-color: #607d8b; /* Warna saat menu aktif */
        border-radius: 5px;
    }

    .main-panel {
        padding: 20px;
    }
</style>
<style>
    /* Sidebar transparan */
    .sidebar {
        background-color: rgba(69, 90, 100, 0.3); /* Transparansi tinggi */
        color: white; /* Warna teks kontras */
        border-right: 1px solid rgba(255, 255, 255, 0.1); /* Border lembut */
    }

    /* Item menu sidebar */
    .sidebar .nav-item .nav-link {
        color: #ffffff; /* Teks putih cerah */
        font-weight: bold; /* Tebal agar lebih terlihat */
        font-size: 15px; /* Ukuran font sedikit lebih besar */
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.6); /* Efek bayangan pada teks */
    }

    /* Menu aktif */
    .sidebar .nav-item.active .nav-link {
        background-color: rgba(96, 125, 139, 0.4); /* Warna transparan untuk menu aktif */
        border-radius: 5px; /* Sudut membulat */
        font-size: 16px; /* Ukuran font lebih besar untuk menu aktif */
        color: #ffcc00; /* Warna teks kuning pada menu aktif agar menarik perhatian */
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8); /* Bayangan lebih jelas untuk teks aktif */
    }

    /* Hover efek pada item menu */
    .sidebar .nav-item .nav-link:hover {
        background-color: rgba(96, 125, 139, 0.5); /* Transparansi saat hover */
        color: #ffcc00; /* Warna teks kuning saat hover */
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8); /* Tambahkan efek bayangan lebih kuat */
    }

    /* Teks menu kategori */
    .sidebar .nav-category {
        color: rgba(255, 255, 255, 0.8); /* Transparansi lebih rendah agar lebih jelas */
        font-weight: bold;
        font-size: 14px; /* Sedikit lebih besar */
        text-transform: uppercase; /* Huruf kapital untuk kategori */
    }
</style>


</head>

<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start">
                <div class="me-3">
                    <button class="navbar-toggler navbar-toggler align-self-center" type="button" data-bs-toggle="minimize">
                        <span class="icon-menu"></span>
                    </button>
                </div>
                <div>
                    <a class="navbar-brand brand-logo" href="../../index.html">
                    <h1>RF CAFE</h1>
                    </a>
                    <a class="navbar-brand brand-logo-mini" href="../../index.html">
                        <img src="<?= base_url() ?>/public/images/logo-mini.svg" alt="logo" />
                    </a>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-top">
                <ul class="navbar-nav">
                    <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
                        <h1 class="welcome-text"> <span class="text-black fw-bold"><?= session()->get("nama") ?></span></h1>
                        <h3 class="welcome-sub-text"> Berkerjalah dengan sopan & jujur :) </h3>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a type="button" class="btn btn-social-icon-text btn-dribbble" href="dashboard/logout"><i class="mdi mdi-account-check"></i>Log out</a>
                    </li>
                </ul>
                <button class="navbar-toggler navbar-toggler-right d-lg-none align-self-center" type="button" data-bs-toggle="offcanvas">
                    <span class="mdi mdi-menu"></span>
                </button>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial -->
            <!-- partial:../../partials/_sidebar.html -->
            <nav class="sidebar sidebar-offcanvas" id="sidebar">
                <ul class="nav">
                    <li class="nav-item <?php if ($url->getSegment(3) == "antrian") {
                                            echo "active";
                                        } ?>">
                        <a class="nav-link" href="antrian">
                            <i class="menu-icon mdi mdi-chair-school"></i>
                            <span class="menu-title">Antrian</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if ($url->getSegment(3) == "laporan") {
                                            echo "active";
                                        } ?>">
                        <a class="nav-link" href="laporan">
                            <i class="menu-icon mdi mdi-book-open-page-variant"></i>
                            <span class="menu-title">Laporan</span>
                        </a>
                    </li>
                    <li class="nav-item nav-category"></li>
                    <li class="nav-item <?php if ($url->getSegment(3) == "menu") {
                                            echo "active";
                                        } ?>">
                        <a class="nav-link" href="menu">
                            <i class="menu-icon mdi mdi-food-fork-drink"></i>
                            <span class="menu-title">Menu</span>
                        </a>
                    </li>
                    <li class="nav-item <?php if ($url->getSegment(3) == "meja") { echo "active"; } ?>">
                        <a class="nav-link" href="meja">
                            <i class="menu-icon mdi mdi-table"></i>
                            <span class="menu-title">Meja</span>
                        </a>
                    </li>

                    <?php if (session()->get("rule") == 1) : ?>
                        <li class="nav-item <?php if ($url->getSegment(3) == "user") {
                                                echo "active";
                                            } ?>">
                            <a class="nav-link" href="user">
                                <i class="menu-icon mdi mdi-account-multiple"></i>
                                <span class="menu-title">User</span>
                            </a>
                        </li>
                    <?php endif; ?>
                </ul>
            </nav>
            <!-- partial -->
            <div class="main-panel">
                <div class="content-wrapper">
                    <?php $this->renderSection('content'); ?>
                </div>
                <!-- content-wrapper ends -->
                <!-- partial:../../partials/_footer.html -->
                <footer class="footer">
                    <div class="d-sm-flex justify-content-center justify-content-sm-between">
                        <span class="text-muted text-center text-sm-left d-block d-sm-inline-block">RF CAFE</span>
                        <span class="float-none float-sm-right d-block mt-1 mt-sm-0 text-center">IG @RF_CAFEBNG</span>
                    </div>
                </footer>
            </div>
            <!-- partial -->
            <!-- main-panel ends -->
        </div>
        <!-- page-body-wrapper ends -->
    </div>
    <!-- endinject -->
    <!-- container-scroller -->
    <!-- plugins:js -->
    <!-- Plugin js for this page -->
    <script src="<?= base_url() ?>/public/vendors/js/vendor.bundle.base.js"></script>
    <script src="<?= base_url() ?>/public/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
    <!-- End plugin js for this page -->
    <!-- inject:js -->
    <script src="<?= base_url() ?>/public/js/off-canvas.js"></script>
    <script src="<?= base_url() ?>/public/js/hoverable-collapse.js"></script>
    <script src="<?= base_url() ?>/public/js/settings.js"></script>
    <script src="<?= base_url() ?>/public/js/todolist.js"></script>
    <!-- endinject -->
    <!-- Custom js for this page-->
    <!-- End custom js for this page-->
</body>

</html>