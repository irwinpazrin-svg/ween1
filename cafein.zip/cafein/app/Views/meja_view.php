<?php $this->extend('template') ?>

<?php $this->section('content') ?>
<div class="row">
    <div class="col-md-8">
        <div class="card">
            <div class="card-header">
                <h4 class="card-title">Daftar Meja</h4>
            </div>
            <div class="card-body">
                <!-- Display flash message -->
                <?php if (session()->getFlashdata('message')): ?>
                    <div class="alert alert-warning">
                        <?= session()->getFlashdata('message'); ?>
                    </div>
                <?php endif; ?>
                
                <table class="table table-bordered">
                    <thead class="thead-light">
                        <tr>
                            <th>Nomor Meja</th>
                            <th>Status</th>
                            <th>Waktu Terboking</th> <!-- New Column for Waktu Terboking -->
                            <th>Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($semua_meja as $meja): ?>
                        <tr>
                            <td><?= $meja['nomor_meja']; ?></td>
                            <td>
                                <?php if ($meja['status'] == 'kosong'): ?>
                                    <span class="text-success">Kosong</span>
                                <?php elseif ($meja['status'] == 'penuh'): ?>
                                    <span class="text-danger">Penuh</span>
                                <?php else: ?>
                                    <span class="text-warning">Terboking</span>
                                <?php endif; ?>
                            </td>
                            <td>
                                <?php if ($meja['status'] == 'terboking'): ?>
                                    <?php
                                        $waktu = new DateTime($meja['waktu_terboking']); // Membuat objek DateTime dari waktu terboking
                                        $waktu->setTimezone(new DateTimeZone('Asia/Makassar')); // Set ke zona waktu WITA
                                        echo $waktu->format('H:i'); // Tampilkan hanya jam dan menit
                                    ?>
                                <?php else: ?>
                                    -
                                <?php endif; ?>
                            </td>
                            <td>
                                <!-- Only allow users with role 0 (karyawan) or 1 (admin) to change the status -->
                                <?php if (session()->get('rule') == 1 || session()->get('rule') == 0): ?>
                                    <form action="<?= base_url('meja/ubahStatusMeja'); ?>" method="post" style="display:inline;">
                                        <input type="hidden" name="nomor_meja" value="<?= $meja['nomor_meja']; ?>">
                                        <input type="hidden" name="status" value="kosong">
                                        <button type="submit" class="btn btn-success btn-sm">Kosong</button>
                                    </form>
                                    <form action="<?= base_url('meja/ubahStatusMeja'); ?>" method="post" style="display:inline;">
                                        <input type="hidden" name="nomor_meja" value="<?= $meja['nomor_meja']; ?>">
                                        <input type="hidden" name="status" value="terboking">
                                        <button type="submit" class="btn btn-warning btn-sm">Terboking</button>
                                    </form>
                                <?php else: ?>
                                    <!-- Message for unauthorized users -->
                                    <span class="text-muted">Tidak dapat mengubah status</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="<?= base_url('public/js/jquery/jquery.min.js'); ?>"></script>
<script>
    function ubahStatus(id) {
        $.ajax({
            url: '<?= base_url() ?>/meja/ubahStatus',
            method: 'post',
            data: { id: id, status: $("#status" + id).val() },
            dataType: 'json',
            success: function(data) {
                alert("Status berhasil diperbarui");
            }
        });
    }

    $(document).ready(function() {
        muatData(); // Load data when the page is ready
    });
</script>

<?php $this->endSection() ?>
