<!DOCTYPE html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>RFcafe :)</title>
    <!-- plugins:css -->
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/feather/feather.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/mdi/css/materialdesignicons.min.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/ti-icons/css/themify-icons.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/typicons/typicons.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/simple-line-icons/css/simple-line-icons.css">
    <link rel="stylesheet" href="<?= base_url() ?>/public/vendors/css/vendor.bundle.base.css">
    <!-- inject:css -->
    <link rel="stylesheet" href="<?= base_url() ?>/public/css/vertical-layout-light/style.css">
    <!-- endinject -->
    <link rel="shortcut icon" href="<?= base_url() ?>/public/images/LogoCafe.JPG" />
    <style>
    body {
        background-color: #cfd8dc; /* Warna latar belakang */
        background-image: url('<?= base_url() ?>/public/images/cafe_b.JPEG'); /* Tambahkan gambar */
        background-repeat: no-repeat;
        background-size: cover;
        background-attachment: fixed;
    }

    .content-wrapper {
        background-color: rgba(255, 255, 255, 0.9); /* Warna putih dengan transparansi */
        border-radius: 10px; /* Membuat sudut membulat */
        padding: 20px;
        box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); /* Tambahkan efek bayangan */
    }

    .sidebar {
        background-color: #455a64; /* Warna sidebar */
        color: white; /* Warna teks sidebar */
    }

    .sidebar .nav-item.active {
        background-color: #607d8b; /* Warna saat menu aktif */
        border-radius: 5px;
    }

    .main-panel {
        padding: 20px;
    }
</style>
<style>
    /* Sidebar transparan */
    .sidebar {
        background-color: rgba(69, 90, 100, 0.3); /* Transparansi tinggi */
        color: white; /* Warna teks kontras */
        border-right: 1px solid rgba(255, 255, 255, 0.1); /* Border lembut */
    }

    /* Item menu sidebar */
    .sidebar .nav-item .nav-link {
        color: #ffffff; /* Teks putih cerah */
        font-weight: bold; /* Tebal agar lebih terlihat */
        font-size: 15px; /* Ukuran font sedikit lebih besar */
        text-shadow: 1px 1px 2px rgba(0, 0, 0, 0.6); /* Efek bayangan pada teks */
    }

    /* Menu aktif */
    .sidebar .nav-item.active .nav-link {
        background-color: rgba(96, 125, 139, 0.4); /* Warna transparan untuk menu aktif */
        border-radius: 5px; /* Sudut membulat */
        font-size: 16px; /* Ukuran font lebih besar untuk menu aktif */
        color: #ffcc00; /* Warna teks kuning pada menu aktif agar menarik perhatian */
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8); /* Bayangan lebih jelas untuk teks aktif */
    }

    /* Hover efek pada item menu */
    .sidebar .nav-item .nav-link:hover {
        background-color: rgba(96, 125, 139, 0.5); /* Transparansi saat hover */
        color: #ffcc00; /* Warna teks kuning saat hover */
        text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.8); /* Tambahkan efek bayangan lebih kuat */
    }

    /* Teks menu kategori */
    .sidebar .nav-category {
        color: rgba(255, 255, 255, 0.8); /* Transparansi lebih rendah agar lebih jelas */
        font-weight: bold;
        font-size: 14px; /* Sedikit lebih besar */
        text-transform: uppercase; /* Huruf kapital untuk kategori */
    }
</style>
</head>




</>


<body>
    <div class="container-scroller">
        <!-- partial:../../partials/_navbar.html -->
        <nav class="navbar default-layout col-lg-12 col-12 p-0 fixed-top d-flex align-items-top flex-row">
            <div class="text-center navbar-brand-wrapper d-flex align-items-center justify-content-start pl-3">

                <div>
                    <a class="navbar-brand brand-logo" href="../../index.html">
                        <h1>RF CAFE</h1>
                    </a>
                    <a class="navbar-brand brand-logo-mini" href="../../index.html">
                        <h1>C</h1>
                    </a>
                </div>
            </div>
            <div class="navbar-menu-wrapper d-flex align-items-top">
                <ul class="navbar-nav">
                    <li class="nav-item font-weight-semibold d-none d-lg-block ms-0">
                        <h1 class="welcome-text">Selamat Datang, <span class="text-black fw-bold">:)</span></h1>
                        <p>Kalu sudah melakukan pemesan silahkan ke kasir untuk melakukan pembayaran agar pesanan segara di peroses</p>
                    </li>
                </ul>
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <button type="button" class="btn btn-social-icon-text btn-warning" onclick="bukaModalKeranjang()"><i class="mdi mdi-cart-outline"></i>Keranjang <b id="jmlPesanan">(0)</b></button>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="btn btn-social-icon-text btn-google" onclick="bukaModalLogin()"><i class="mdi mdi-account-check"></i>Admin</button>
                    </li>
                    <li class="nav-item">
                        <button type="button" class="btn btn-primary btn-social-icon-text" onclick="window.location.href='<?= base_url('meja') ?>'">
                            <i class="mdi mdi-table"></i> Meja
                        </button>
                    </li>



                    </li>
                </ul>
            </div>
        </nav>
        <!-- partial -->
        <div class="container-fluid page-body-wrapper">
            <!-- partial -->
            <div class="main-panel" style="margin-left: auto; margin-right:auto;">
                <?php if ($makanan) : ?>
                    <div class="content-wrapper text-center">
                        <h2>Aneka Makanan</h2>
                        <hr>
                        <div class="row">
                            <?php for ($i = 0; $i < count($makanan); $i++) :
                                if ($makanan[$i]["jenis"] == 1) : ?>
                                    <div class="col-lg-3 grid-margin stretch-card">
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body p-0">
                                                <img src="<?= base_url() ?>/public/images/menu/<?= $makanan[$i]["foto"] ?>" class="card-img-top" <?php if ($makanan[$i]["status"] == 0) {
                                                                                                                                                        echo 'style = "filter: grayscale(100%);-webkit-filter: grayscale(100%);"';
                                                                                                                                                    } ?> alt="...">
                                                <div class="card-body text-center">
                                                    <h5><?= $makanan[$i]["nama"] ?></h5>
                                                    <i>Rp. <?= $makanan[$i]["harga"] ?></i><br>
                                                    <button class="btn btn-warning btn-sm btn-fw mt-2" <?php if ($makanan[$i]["status"] == 0) {
                                                                                                            echo "disabled";
                                                                                                        } ?> onclick='tambahPesanan(<?= $makanan[$i]["id"] ?>, "<?= $makanan[$i]["nama"] ?>", <?= $makanan[$i]["harga"] ?> )'><?php if ($makanan[$i]["status"] == 0) {
                                                                                                                                                                                                                                    echo "Habis";
                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                    echo "Tambah";
                                                                                                                                                                                                                                } ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                endif;
                            endfor; ?>
                        </div>
                    </div>
                <?php
                endif;
                if ($snack) : ?>
                    <div class="content-wrapper text-center">
                        <h2>Aneka Snack</h2>
                        <hr>
                        <div class="row">
                            <?php for ($i = 0; $i < count($snack); $i++) :
                                if ($snack[$i]["jenis"] == 2) : ?>
                                    <div class="col-lg-3 grid-margin stretch-card">
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body p-0">
                                                <img src="<?= base_url() ?>/public/images/menu/<?= $snack[$i]["foto"] ?>" class="card-img-top" <?php if ($snack[$i]["status"] == 0) {
                                                                                                                                                    echo 'style = "filter: grayscale(100%);-webkit-filter: grayscale(100%);"';
                                                                                                                                                } ?> alt="...">
                                                <div class="card-body text-center">
                                                    <h5><?= $snack[$i]["nama"] ?></h5>
                                                    <i>Rp. <?= $snack[$i]["harga"] ?></i><br>
                                                    <button class="btn btn-warning btn-sm btn-fw mt-2" <?php if ($snack[$i]["status"] == 0) {
                                                                                                            echo "disabled";
                                                                                                        } ?> onclick='tambahPesanan(<?= $snack[$i]["id"] ?>, "<?= $snack[$i]["nama"] ?>", <?= $snack[$i]["harga"] ?> )'><?php if ($snack[$i]["status"] == 0) {
                                                                                                                                                                                                                            echo "Habis";
                                                                                                                                                                                                                        } else {
                                                                                                                                                                                                                            echo "Tambah";
                                                                                                                                                                                                                        } ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                endif;
                            endfor; ?>
                        </div>
                    </div>
                <?php endif;
                if ($minumanDingin) : ?>
                    <div class="content-wrapper text-center">
                        <h2>Aneka Minuman Dingin</h2>
                        <hr>
                        <div class="row">
                            <?php for ($i = 0; $i < count($minumanDingin); $i++) :
                                if ($minumanDingin[$i]["jenis"] == 3) : ?>
                                    <div class="col-lg-3 grid-margin stretch-card">
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body p-0">
                                                <img src="<?= base_url() ?>/public/images/menu/<?= $minumanDingin[$i]["foto"] ?>" class="card-img-top" <?php if ($minumanDingin[$i]["status"] == 0) {
                                                                                                                                                            echo 'style = "filter: grayscale(100%);-webkit-filter: grayscale(100%);"';
                                                                                                                                                        } ?> alt="...">
                                                <div class="card-body text-center">
                                                    <h5><?= $minumanDingin[$i]["nama"] ?></h5>
                                                    <i>Rp. <?= $minumanDingin[$i]["harga"] ?></i><br>
                                                    <button class="btn btn-warning btn-sm btn-fw mt-2" <?php if ($minumanDingin[$i]["status"] == 0) {
                                                                                                            echo "disabled";
                                                                                                        } ?> onclick='tambahPesanan(<?= $minumanDingin[$i]["id"] ?>, "<?= $minumanDingin[$i]["nama"] ?>", <?= $minumanDingin[$i]["harga"] ?> )'><?php if ($minumanDingin[$i]["status"] == 0) {
                                                                                                                                                                                                                                                    echo "Habis";
                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                    echo "Tambah";
                                                                                                                                                                                                                                                } ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                endif;
                            endfor; ?>
                        </div>
                    </div>
                <?php endif;
                if ($minumanPanas) : ?>
                    <div class="content-wrapper text-center">
                        <h2>Aneka Minuman Panas</h2>
                        <hr>
                        <div class="row">
                            <?php for ($i = 0; $i < count($minumanPanas); $i++) :
                                if ($minumanPanas[$i]["jenis"] == 4) : ?>
                                    <div class="col-lg-3 grid-margin stretch-card">
                                        <div class="card" style="width: 18rem;">
                                            <div class="card-body p-0">
                                                <img src="<?= base_url() ?>/public/images/menu/<?= $minumanPanas[$i]["foto"] ?>" class="card-img-top" <?php if ($minumanPanas[$i]["status"] == 0) {
                                                                                                                                                            echo 'style = "filter: grayscale(100%);-webkit-filter: grayscale(100%);"';
                                                                                                                                                        } ?> alt="...">
                                                <div class="card-body text-center">
                                                    <h5><?= $minumanPanas[$i]["nama"] ?></h5>
                                                    <i>Rp. <?= $minumanPanas[$i]["harga"] ?></i><br>
                                                    <button class="btn btn-warning btn-sm btn-fw mt-2" <?php if ($minumanPanas[$i]["status"] == 0) {
                                                                                                            echo "disabled";
                                                                                                        } ?> onclick='tambahPesanan(<?= $minumanPanas[$i]["id"] ?>, "<?= $minumanPanas[$i]["nama"] ?>", <?= $minumanPanas[$i]["harga"] ?> )'><?php if ($minumanPanas[$i]["status"] == 0) {
                                                                                                                                                                                                                                                    echo "Habis";
                                                                                                                                                                                                                                                } else {
                                                                                                                                                                                                                                                    echo "Tambah";
                                                                                                                                                                                                                                                } ?></button>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            <?php
                                endif;
                            endfor; ?>
                        </div>
                    </div>
                <?php endif; ?>

                <!-- Modal -->
                <div class="modal fade" id="modalKeranjang" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Pesanan</h5>
            </div>
            <div class="modal-body p-0 text-center">
                <div class="row">
                    <div class="col-10">
                        <div class="form-group">
                            <div class="input-group">
                                <div class="input-group-prepend">
                                    <span class="input-group-text bg-warning text-white">Nama</span>
                                </div>
                                <input type="text" id="nama" class="form-control" aria-label="Amount (to the nearest dollar)">
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="form-group">
                            <label class="text-warning">Pilih No Meja</label>
                            <div class="row">
                                <?php for ($i = 1; $i <= 16; $i++) { ?>
                                    <div class="col-md-3 mb-3">
                                        <button type="button" class="btn btn-primary table-button w-100" data-table-number="<?= $i ?>" onclick="selectTable(<?= $i ?>)">
                                            Meja <?= $i ?>
                                        </button>
                                    </div>
                                <?php } ?>
                                <!-- Tombol untuk Order Bawa Pulang -->
                                <div class="col-md-3 mb-3">
                                    <button type="button" class="btn btn-primary table-button w-100" data-table-number="<?= $i ?>" onclick="selectTable(<?= $i ?>)">
                                    Take away
                                    </button>
                                </div>
                            </div>
                            <!-- Input tersembunyi untuk menyimpan nomor meja yang dipilih -->
                            <input type="hidden" id="noMeja" name="noMeja">
                        </div>
</div>

<script>
    function selectTable(tableNumber) {
        document.getElementById('noMeja').value = tableNumber;
        // Lakukan aksi lain yang diperlukan setelah memilih meja
    }

    function orderTakeaway() {
        // Logika untuk memproses order bawa pulang
        alert("Anda memilih Order Bawa Pulang.");
        // Anda bisa menambahkan logika lain seperti mengarahkan ke halaman pemesanan bawa pulang
    }
</script>
                </div>

                <!-- Tabel Pesanan -->
                <table class="table text-center bg-white" id="dataTable">
                    <thead>
                        <tr>
                            <th>Nama</th>
                            <th>Jml</th>
                            <th>Harga</th>
                            <th>Total</th>
                            <th>Hapus</th>
                        </tr>
                    </thead>
                    <tbody id="tabelPesanan">
                        <tr>
                            <td colspan="5">Data Kosong</td>
                        </tr>
                    </tbody>
                </table>

                <!-- Menambahkan Total Harga -->
                <div class="row">
                    <div class="col-12">
                        <h5>Total Keseluruhan: <span id="totalHarga"></span></h5>
                    </div>
                </div>

                <b id="peringatan" class="badge badge-danger">Silahkan isi nama dan no meja.</b><br>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" onclick="tutupModalKeranjang()">Tutup</button>
                <button type="button" class="btn btn-warning" onclick="prosesTransaksi()" id="simpanTransaksi">Pesan dan Bayar</button>
            </div>
        </div>
    </div>
</div>

                <!-- Modal -->
                <div class="modal fade" id="modalSelesai" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Pesanan Berhasil.</h5>
                            </div>
                            <div class="modal-body">
                                Pesanan Berhasil dibuat. atas nama <b id="namaPemesan"></b> dengan lokasi meja <b id="lokasiMeja"></b>.
                                <br> <br> Mohon Menunggu sebentar kak. semoga anda dapat menikmati suasana rindu cafe ini. <br> <br>
                                <b>Terimakasih... :)</b><br><br>
                                <i>langsung dibayar ya.. </i>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-warning" onclick="tutupModalSelesai()">Siap :)</button>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Modal -->
                <div class="modal fade" id="modalLogin" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="exampleModalLabel">Login admin.</h5>
                            </div>
                            <div class="modal-body">
                                <div id="errorLogin" class="mb-3"></div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <select id="idUser" class="form-control text-dark">
                                            <?php for ($i = 0; $i < count($user); $i++) {
                                                echo "<option value='" . $user[$i]["id"] . "'>" . $user[$i]["nama"] . "</option>";
                                            } ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="input-group">
                                        <div class="input-group-prepend">
                                            <span class="input-group-text bg-warning text-white">Password</span>
                                        </div>
                                        <input type="password" id="pass" class="form-control" aria-label="Amount (to the nearest dollar)">
                                    </div>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" onclick="tutupModalLogin()">Batal</button>
                                <button type="button" class="btn btn-warning" onclick="login()" id="simpanTransaksi">Log in</button>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- main-panel ends -->
            </div>
            <!-- page-body-wrapper ends -->
        </div>
        
        
        <script src="<?php echo base_url() ?>/public/js/jquery/jquery.min.js"></script>
<script>
    // Inisialisasi variabel pesanan dan status
    var pesanan = [];
    var ditemukan = false;
    var jmlPesanan = 0;

    // Fungsi untuk menampilkan modal keranjang
    function bukaModalKeranjang() {
        tampilkanPesanan();
        $("#modalKeranjang").modal("show");
        $("#peringatan").hide();
    }

    // Fungsi untuk menampilkan modal login
    function bukaModalLogin() {
        $("#modalLogin").modal("show");
    }

    // Fungsi login
    function login() {
        var idUser = $("#idUser").val();
        var pass = $("#pass").val();

        if (pass === "") {
            $("#pass").focus();
        } else {
            $.ajax({
                type: 'POST',
                data: { idUser: idUser, pass: pass },
                url: '<?= base_url() ?>/dashboard/auth',
                dataType: 'json',
                success: function(data) {
                    if (data === "") {
                        window.location.href = "antrian";
                    } else {
                        $("#errorLogin").html(data);
                    }
                }
            });
        }
    }

    function selectTable(tableNumber) {
        // Simpan nomor meja yang dipilih ke dalam input tersembunyi
        document.getElementById("noMeja").value = tableNumber;

        // Ganti gaya tombol yang dipilih untuk menandai pilihan
        let buttons = document.querySelectorAll('.table-button');
        buttons.forEach(button => button.classList.remove('btn-success')); // Reset tombol lain
        document.querySelector(`[data-table-number="${tableNumber}"]`).classList.add('btn-success'); // Tandai tombol yang dipilih
    }

    // Fungsi untuk memproses transaksi
    function prosesTransaksi() {
        var nama = $('#nama').val();
        var noMeja = $('#noMeja').val();

        if (nama === "") {
            $("#nama").focus();
            $("#peringatan").show();
        } else if (noMeja === "") {
            $("#noMeja").focus();
            $("#peringatan").show();
        } else {
            $("#simpanTransaksi").html('<i class="mdi mdi-reload fa-pulse"></i> Memproses..');
            $.ajax({
                type: 'POST',
                url: '<?= base_url() ?>/dashboard/tambahPesanan',
                data: { pesanan: pesanan, nama: nama, noMeja: noMeja },
                dataType: 'json',
                success: function(data) {
                    $("#modalKeranjang").modal("hide");
                    pesanan = [];
                    $('#nama').val("");
                    $('#noMeja').val("");
                    tampilkanPesanan();

                    $("#simpanTransaksi").html('Pesan dan Bayar');
                    $("#namaPemesan").html(nama);
                    $("#lokasiMeja").html(noMeja);
                    $("#modalSelesai").modal("show");
                }
            });
        }
    }

    // Fungsi untuk mengelola status ketersediaan meja
    let tableAvailability = [
        true,  // Meja 1 tersedia
        false, // Meja 2 tidak tersedia
        // ... tambahkan status meja lainnya
    ];

    function updateTableStatus() {
        $.ajax({
            type: 'POST',
            url: '<?= base_url() ?>/dashboard/tambahPesanan',
            data: { pesanan: pesanan, nama: nama, noMeja: noMeja },
            dataType: 'json',
            success: function(data) {
                $("#modalKeranjang").modal("hide");
                pesanan = [];
                $('#nama').val("");
                $('#noMeja').val("");
                tampilkanPesanan();

                $("#simpanTransaksi").html('Pesan dan Bayar');
                $("#namaPemesan").html(nama);
                $("#lokasiMeja").html(noMeja);
                $("#modalSelesai").modal("show");

                for (let i = 0; i < tableAvailability.length; i++) {
                    const button = document.querySelector(`.table-button[data-table-number="${i + 1}"]`);
                    if (tableAvailability[i]) {
                        button.disabled = false;
                        button.classList.remove('disabled');
                    } else {
                        button.disabled = true;
                        button.classList.add('disabled');
                    }
                }
            },
            error: function() {
                console.log("Gagal mengambil status meja dari server.");
            }
        });
    }

    updateTableStatus();
    setInterval(updateTableStatus, 120000); // Update setiap 2 menit

    document.querySelectorAll('.table-button').forEach(button => {
        button.addEventListener('click', () => {
            const tableNumber = button.getAttribute('data-table-number');
            tableAvailability[tableNumber - 1] = false;
            button.disabled = true;
            button.classList.add('disabled');

            $.ajax({
                url: '<?= base_url() ?>/dashboard/updateTableStatus',
                type: 'POST',
                data: { tableNumber: tableNumber, status: false },
                success: function() {
                    console.log("Status meja diperbarui!");

                    // Timer untuk mengembalikan meja ke status tersedia setelah 2 menit
                    setTimeout(() => {
                        tableAvailability[tableNumber - 1] = true;

                        $.ajax({
                            url: '<?= base_url() ?>/dashboard/updateTableStatus',
                            type: 'POST',
                            data: { tableNumber: tableNumber, status: true },
                            success: function() {
                                console.log("Meja dikembalikan ke status tersedia!");
                                updateTableStatus();
                            },
                            error: function() {
                                console.log("Gagal mengupdate status meja di server.");
                            }
                        });
                    }, 120000); // 2 menit
                },
                error: function() {
                    console.log("Gagal mengupdate status meja di server.");
                }
            });
        });
    });

    // Fungsi untuk menutup modal keranjang dan selesai
    function tutupModalKeranjang() { $("#modalKeranjang").modal("hide"); }
    function tutupModalSelesai() { $("#modalSelesai").modal("hide"); }
    function tutupModalLogin() { $("#modalLogin").modal("hide"); }

    // Fungsi untuk menambah pesanan ke dalam keranjang
    function tambahPesanan(id, nama, harga) {
        ditemukan = false;
        jmlPesanan = 0;

        for (let i = 0; i < pesanan.length; i++) {
            if (pesanan[i][0] === id) {
                pesanan[i][2] += 1;
                ditemukan = true;
            }
            jmlPesanan += pesanan[i][2];
        }

        if (!ditemukan) {
            pesanan.push([id, nama, 1, harga]);
            jmlPesanan += 1;
        }

        $("#jmlPesanan").html("(" + jmlPesanan + ")");
    }

    // Fungsi untuk menampilkan pesanan di modal keranjang
    function tampilkanPesanan() {
        var isiPesanan = "";
        var totalHarga = 0;

        for (let i = 0; i < pesanan.length; i++) {
            var subTotal = pesanan[i][2] * pesanan[i][3]; // Hitung subtotal per item
            totalHarga += subTotal; // Tambahkan ke total harga

            isiPesanan += `
                <tr>
                    <td>${pesanan[i][1]}</td>
                    <td>${pesanan[i][2]}</td>
                    <td>${formatRupiah(pesanan[i][3].toString())}</td>
                    <td>${formatRupiah(subTotal.toString())}</td>
                    <td><button href='#' class='badge badge-danger' onClick='hapusPesanan(${i})'>x</button></td>
                </tr>`;
        }

        if (pesanan.length < 1) {
            $("#simpanTransaksi").prop("disabled", true);
            isiPesanan = "<td colspan='5'>Pesanan Masih Kosong :)</td>";
        } else {
            $("#simpanTransaksi").prop("disabled", false);
        }

        // Tampilkan total harga
        isiPesanan += `
            <tr>
                <td colspan="3" style="text-align: right;"><strong>Total Harga</strong></td>
                <td><strong>${formatRupiah(totalHarga.toString())}</strong></td>
                <td></td>
            </tr>`;

        $("#tabelPesanan").html(isiPesanan);
    }

    // Fungsi untuk menghapus pesanan
    function hapusPesanan(id) {
        pesanan.splice(id, 1);
        tampilkanPesanan();
    }

    // Fungsi untuk format rupiah
    function formatRupiah(angka, prefix) {
        var number_string = angka.replace(/[^,\d]/g, '').toString(),
            split = number_string.split(','),
            sisa = split[0].length % 3,
            rupiah = split[0].substr(0, sisa),
            ribuan = split[0].substr(sisa).match(/\d{3}/gi);

        if (ribuan) {
            separator = sisa ? '.' : '';
            rupiah += separator + ribuan.join('.');
        }

        rupiah = split[1] != undefined ? rupiah + ',' + split[1] : rupiah;
        return prefix == undefined ? rupiah : (rupiah ? 'Rp. ' + rupiah : '');
    }
</script>


        <script src="<?= base_url() ?>/public/vendors/js/vendor.bundle.base.js"></script>
        <script src="<?= base_url() ?>/public/vendors/bootstrap-datepicker/bootstrap-datepicker.min.js"></script>
        <script src="<?= base_url() ?>/public/js/off-canvas.js"></script>
        <script src="<?= base_url() ?>/public/js/hoverable-collapse.js"></script>
        <script src="<?= base_url() ?>/public/js/template.js"></script>
        <script src="<?= base_url() ?>/public/js/settings.js"></script>
        <script src="<?= base_url() ?>/public/js/todolist.js"></script>
        <!-- endinject -->
</body>

</html>