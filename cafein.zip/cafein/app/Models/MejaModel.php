<?php

namespace App\Models;

use CodeIgniter\Model;

class MejaModel extends Model
{
    // Nama tabel di database
    protected $table = 'meja';

    // Primary key dari tabel
    protected $primaryKey = 'id_meja';

    // Kolom yang diizinkan untuk diisi
    protected $allowedFields = ['semua_meja', 'status', 'waktu_terboking']; // Tambahkan 'waktu_terboking' ke sini

    // Jika Anda ingin menggunakan timestamps
    protected $useTimestamps = true; // Jika Anda memiliki kolom created_at dan updated_at

    // Jika Anda ingin mengatur nama kolom timestamps
    protected $createdField = 'created_at';
    protected $updatedField = 'updated_at';

    // Fungsi untuk mendapatkan semua meja
    public function getAllMeja()
    {
        return $this->findAll(); // Mengambil semua data dari tabel meja
    }

    // Fungsi untuk mendapatkan meja berdasarkan ID
    public function getMejaById($id)
    {
        return $this->find($id); // Mengambil data meja berdasarkan ID
    }

    // Fungsi untuk menambahkan meja baru
    public function addMeja($data)
    {
        if ($this->insert($data)) {
            return $this->find($this->insertID()); // Mengembalikan data meja yang baru ditambahkan
        }
        return false; // Mengembalikan false jika gagal
    }

    // Fungsi untuk memperbarui meja
    public function updateMeja($id, $data)
    {
        if ($this->update($id, $data)) {
            return $this->find($id); // Mengembalikan data meja yang diperbarui
        }
        return false; // Mengembalikan false jika gagal
    }

    // Fungsi untuk menghapus meja
    public function deleteMeja($id)
    {
        return $this->delete($id); // Menghapus meja berdasarkan ID
    }

    // Fungsi untuk mengubah status meja
    public function updateStatusMeja($nomor_meja, $status)
    {
        log_message('debug', 'Mencari nomor_meja: ' . $nomor_meja);

        $meja = $this->where('nomor_meja', $nomor_meja)->first();

        if ($meja && isset($meja[$this->primaryKey])) {
            log_message('debug', 'Meja ditemukan. Mengubah status meja dengan ID: ' . $meja[$this->primaryKey] . ' ke status: ' . $status);
            return $this->update($meja[$this->primaryKey], ['status' => $status]);
        } else {
            log_message('error', 'Meja dengan nomor ' . $nomor_meja . ' tidak ditemukan.');
            return false; // Data meja tidak ditemukan
        }
    }
}
